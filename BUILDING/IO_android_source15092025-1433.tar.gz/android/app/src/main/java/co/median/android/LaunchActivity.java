package co.median.android;

public class LaunchActivity extends MainActivity{
}
